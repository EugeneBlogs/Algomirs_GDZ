N = int(input())
k = 0
step_2 = 1
while step_2 < N:
    step_2 *= 2
    k += 1
print(k)
