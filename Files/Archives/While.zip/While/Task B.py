a = int(input())
s = 0
k = 0
while a != 0:
    s += a
    k += 1
    a = int(input())
print(s / k)
