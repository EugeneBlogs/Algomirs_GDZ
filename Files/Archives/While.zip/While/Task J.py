x = int(input())
d = 2
while x % d != 0:
    d += 1
print(d)
