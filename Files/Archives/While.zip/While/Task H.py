x = int(input())
y = int(input())
k = 1
while x < y:
    x *= 1.1
    k += 1
print(k)
