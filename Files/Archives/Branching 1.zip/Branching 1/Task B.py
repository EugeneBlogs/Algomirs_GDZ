a = int(input())
b = int(input())
c = int(input())
mx = a
if b > mx:
    mx = b
if c > mx:
    mx = c
print(mx)
