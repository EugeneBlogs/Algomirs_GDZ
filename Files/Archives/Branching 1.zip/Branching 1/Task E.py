a = int(input())
b = int(input())
n = int(input())
s = (a * 100 + b) * n
e = s // 100
f = s % 100
print(e, f)
