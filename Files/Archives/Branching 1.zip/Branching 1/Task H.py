k = int(input())
if (k % 4 == 0 and k >= 4) or k == 1:
    print("YES")
else:
    print("NO")
