N = int(input())
count = 0
for i in range(N):
    a = int(input())
    if a == 0:
        count += 1
print(count)
