N = int(input())
summa = 0
for i in range(N):
    summa += int(input())
print(summa)
