summa = 0
for i in range(100):
    summa += int(input())
print(summa)
