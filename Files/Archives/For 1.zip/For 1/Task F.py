N = int(input())
result = 1
for i in range(N):
    result *= 2
print(result)
