a = int(input())
b = int(input())
if a > b:
    print(">")
elif a < b:
    print("<")
else:
    print("=")