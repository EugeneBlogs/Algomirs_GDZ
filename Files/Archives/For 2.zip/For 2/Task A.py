N = int(input())
for i in range(1, N + 1):
    sq = i ** 2
    if sq <= N:
        print(sq)
