N = int(input())
summa = 1
for i in range(1, N + 1):
    summa += 2 ** i
print(summa)
