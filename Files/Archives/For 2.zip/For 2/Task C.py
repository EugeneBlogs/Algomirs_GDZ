n = int(input())
summa = 0
for i in range(1, n + 1):
    summa += i ** 2
print(summa)
