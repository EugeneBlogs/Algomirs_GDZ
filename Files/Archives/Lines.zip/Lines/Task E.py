N = input()
count = 0
for s in N:
    if s == "0":
        count += 1
print(count)