str = input()
words = str.split(" ")
print(words[1], words[0])
