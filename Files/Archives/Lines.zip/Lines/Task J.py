str = input()
words = str.split(" ")
print(words[0])
