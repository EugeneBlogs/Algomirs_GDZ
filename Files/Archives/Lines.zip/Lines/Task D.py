str = input()
count = 0
for s in str:
    if s.isdigit():
        count += 1
print(count)
