s1 = input()
s2 = input()
if s1 == s2:
    print("yes")
else:
    print("no")
