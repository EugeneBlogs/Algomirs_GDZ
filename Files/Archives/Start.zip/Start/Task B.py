a = int(input())
a = a * 15
print(a)
