a = int(input())
a = a // 2
print(a)
