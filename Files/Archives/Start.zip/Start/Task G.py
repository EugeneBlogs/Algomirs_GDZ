a = int(input())
b = int(input())
c = int(input())
d = (a + b) * c
print(d)
