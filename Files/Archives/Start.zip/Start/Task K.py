a = int(input())
b = int(input())
c = int(input())
s = (a + b + c) % 4
print(s)
