h = int(input())
m = int(input())
r = h * 60 + m
print(r)
