a = int(input())
a = a + 10
print(a)
