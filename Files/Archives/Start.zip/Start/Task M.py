a = int(input())
b = int(input())
s = a % b
print(s)
