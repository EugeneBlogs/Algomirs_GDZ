h = int(input())
m = int(input())
s = int(input())
r = (h * 3600) + (m * 60) + s
print(r)
