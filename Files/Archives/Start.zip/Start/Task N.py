a = int(input())
d = a // 10
e = a % 10
print(d)
print(e)
