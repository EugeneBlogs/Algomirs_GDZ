a = int(input())
s = a // 100
d = (a // 10) % 10
e = a % 10
print(s)
print(d)
print(e)
