a = int(input())
b = (a % 5) * a
print(b)
