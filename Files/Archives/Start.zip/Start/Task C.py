a = int(input())
b = a + 5
c = a - 7
print(b)
print(c)
