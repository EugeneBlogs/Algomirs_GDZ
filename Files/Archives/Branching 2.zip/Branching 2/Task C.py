s1 = int(input())
s2 = int(input())
f1 = int(input())
f2 = int(input())
if (s1 + s2 == f1 + f2) or (s1 - s2 == f1 - f2):
    print("YES")
else:
    print("NO")
