n = int(input())
m = int(input())
if n > m:
    print(1)
elif m > n:
    print(2)
else:
    print(0)
