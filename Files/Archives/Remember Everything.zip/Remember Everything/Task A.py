n = int(input())
if n > 0:
    print((1 + n) * n // 2)
else:
    print((-1 + n) * abs(n) // 2 + 1)
