a = int(input())
b = int(input())
print(int((a * (a // b) + b * (b // a)) / (b // a + a // b)))
