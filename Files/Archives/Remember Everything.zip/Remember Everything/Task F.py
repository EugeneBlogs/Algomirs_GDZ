str = input()
if str[1] == "0":
    print(str[0])
else:
    print(f"{str[1]}{str[0]}")
