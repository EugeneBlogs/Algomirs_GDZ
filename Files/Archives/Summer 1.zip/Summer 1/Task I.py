s1 = input()
s2 = input()
if s1 in s2:
    print("yes")
else:
    print("no")