c = input()
if c.isdigit():
    print("yes")
else:
    print("no")
