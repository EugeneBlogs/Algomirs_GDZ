s = input()
for el in s:
    if s.count(el) == 2:
        print(el)
        break