s = input()
print(len(s.split()))