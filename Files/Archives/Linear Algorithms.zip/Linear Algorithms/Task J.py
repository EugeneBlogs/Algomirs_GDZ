v = int(input())
t = int(input())
s = v * t
km = s % 109
print(km)
