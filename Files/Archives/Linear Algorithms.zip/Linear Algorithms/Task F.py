n = int(input())
n = n % 1440
h = n // 60
m = n % 60
print(h, m)
