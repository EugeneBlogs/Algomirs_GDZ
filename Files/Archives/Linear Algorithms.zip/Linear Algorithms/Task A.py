N = int(input())
K = int(input())
r = K // N
print(r)
