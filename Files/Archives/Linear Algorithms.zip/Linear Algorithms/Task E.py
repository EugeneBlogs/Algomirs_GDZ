n = int(input())
a = n // 100
b = (n % 100) // 10
c = n % 10
s = a + b + c
print(s)
