n = int(input())
a = n + 1
b = n - 1
print("The next number for the number " + str(n) + " is " + str(a) + ".")
print("The previous number for the number " + str(n) + " is " + str(b) + ".")
