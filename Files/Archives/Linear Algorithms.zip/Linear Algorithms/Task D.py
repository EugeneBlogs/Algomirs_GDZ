n = int(input())
n = (n % 100) // 10
print(n)
