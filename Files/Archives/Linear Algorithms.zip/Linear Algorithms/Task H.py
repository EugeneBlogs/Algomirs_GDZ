n = int(input())
c = n - n % 2 + 2
print(c)
