n = int(input())
n = n % 10
print(n)
