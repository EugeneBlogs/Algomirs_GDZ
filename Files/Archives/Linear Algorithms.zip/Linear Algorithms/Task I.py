a = int(input())
b = int(input())
c = int(input())
p = a // 2 + b // 2 + c // 2 + a % 2 + b % 2 + c % 2
print(p)
