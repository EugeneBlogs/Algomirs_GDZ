count = 0
a = 1
while a != 0:
    a = int(input())
    if a != 0:
        count += a
print(count)
