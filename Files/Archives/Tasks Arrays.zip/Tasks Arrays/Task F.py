if len(input()) == 3:
    print("YES")
else:
    print("NO")
