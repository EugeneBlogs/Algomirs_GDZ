n = int(input())
a = []
for i in range(1, n + 1):
    a.append(i ** 2)
print(*a)
