a = [int(i) for i in input().split()]
k = int(input())
for i in range(k, len(a) - 1):
    a[i], a[i + 1] = a[i + 1], a[i]
a.pop()
print(*a)
