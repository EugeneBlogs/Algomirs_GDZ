a = int(input())
b = int(input())
print((a ** 2 + b ** 2) ** 0.5)
