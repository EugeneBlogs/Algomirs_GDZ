a = float(input())
n = int(input())
result = 1
for i in range(n):
    result *= a
print(result)
