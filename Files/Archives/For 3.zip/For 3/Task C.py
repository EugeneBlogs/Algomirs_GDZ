a = float(input())
n = int(input())
result = 0
for i in range(n + 1):
    result += a ** i
print(result)
