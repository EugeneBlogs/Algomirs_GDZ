n = input()
print(int(n, 2))
